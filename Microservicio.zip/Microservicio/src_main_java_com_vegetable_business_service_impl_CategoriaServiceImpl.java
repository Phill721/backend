package com.vegetable.business.service.impl;

import com.vegetable.business.dto.CategoriaDTO;
import com.vegetable.business.mapper.CategoriaMapper;
import com.vegetable.business.model.CategoriaEntity;
import com.vegetable.business.model.Categoria;
import com.vegetable.business.repository.CategoriaRepository;
import com.vegetable.business.service.CategoriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class CategoriaServiceImpl implements CategoriaService {

    @Autowired
    private CategoriaRepository categoriaRepository;
    
    @Autowired
    private CategoriaMapper categoriaMapper;

    @Override
    public CategoriaDTO crearCategoria(CategoriaDTO categoriaDTO) {
        if (categoriaRepository.existsByCategoria(categoriaDTO.getCategoria())) {
            throw new RuntimeException("Ya existe una categoría con el tipo: " + categoriaDTO.getCategoria());
        }
        
        CategoriaEntity categoriaEntity = categoriaMapper.toEntity(categoriaDTO);
        CategoriaEntity categoriaGuardada = categoriaRepository.save(categoriaEntity);
        return categoriaMapper.toDTO(categoriaGuardada);
    }

    @Override
    @Transactional(readOnly = true)
    public List<CategoriaDTO> obtenerTodasLasCategorias() {
        return categoriaRepository.findByActivaTrue()
                .stream()
                .map(categoriaMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public CategoriaDTO obtenerCategoriaPorTipo(Categoria categoria) {
        CategoriaEntity categoriaEntity = categoriaRepository.findByCategoria(categoria)
                .orElseThrow(() -> new RuntimeException("Categoría no encontrada: " + categoria));
        return categoriaMapper.toDTO(categoriaEntity);
    }

    @Override
    public void eliminarCategoria(Long id) {
        CategoriaEntity categoria = categoriaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Categoría no encontrada con ID: " + id));
        categoria.setActiva(false);
        categoriaRepository.save(categoria);
    }
}