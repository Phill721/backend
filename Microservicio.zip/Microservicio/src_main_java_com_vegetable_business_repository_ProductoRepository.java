package com.vegetable.business.repository;

import com.vegetable.business.model.ProductoEntity;
import com.vegetable.business.model.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

public interface ProductoRepository extends JpaRepository<ProductoEntity, Long> {
    
    List<ProductoEntity> findByActivoTrue();
    
    List<ProductoEntity> findByCategoriaCategoriaAndActivoTrue(Categoria categoria);
    
    List<ProductoEntity> findByNombreContainingIgnoreCaseAndActivoTrue(String nombre);
    
    @Query("SELECT p FROM ProductoEntity p WHERE p.precio BETWEEN :precioMin AND :precioMax AND p.activo = true")
    List<ProductoEntity> findByPrecioBetween(@Param("precioMin") BigDecimal precioMin, 
                                             @Param("precioMax") BigDecimal precioMax);
    
    Optional<ProductoEntity> findByIdAndActivoTrue(Long id);
    
    List<ProductoEntity> findByStockGreaterThanAndActivoTrue(Integer stock);
}