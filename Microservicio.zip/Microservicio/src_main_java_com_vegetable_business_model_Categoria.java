package com.vegetable.business.model;

public enum Categoria {
    FRUTAS_FRESCAS("Frutas frescas"),
    VERDURAS_ORGANICAS("Verduras Organicas"),
    PRODUCTOS_ORGANICAS("Productos Organicos"),
    PRODUCTOS_LACTEOS("Productos Lacteos");

    private final String descripcion;

    Categoria(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getDescripcion() {
        return descripcion;
    }
}