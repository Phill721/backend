package com.vegetable.business.repository;

import com.vegetable.business.model.CategoriaEntity;
import com.vegetable.business.model.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface CategoriaRepository extends JpaRepository<CategoriaEntity, Long> {
    
    Optional<CategoriaEntity> findByCategoria(Categoria categoria);
    
    List<CategoriaEntity> findByActivaTrue();
    
    Boolean existsByCategoria(Categoria categoria);
}