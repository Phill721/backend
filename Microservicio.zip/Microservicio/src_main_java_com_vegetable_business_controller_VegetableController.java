package com.vegetable.business.controller;

import com.vegetable.business.dto.ProductoDTO;
import com.vegetable.business.dto.CategoriaDTO;
import com.vegetable.business.model.Categoria;
import com.vegetable.business.service.ProductoService;
import com.vegetable.business.service.CategoriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class VegetableController {

    @Autowired
    private ProductoService productoService;
    
    @Autowired
    private CategoriaService categoriaService;

    // ENDPOINTS DE PRODUCTOS
    
    @PostMapping("/productos")
    public ResponseEntity<ProductoDTO> crearProducto(@Valid @RequestBody ProductoDTO productoDTO) {
        ProductoDTO productoCreado = productoService.crearProducto(productoDTO);
        return ResponseEntity.ok(productoCreado);
    }

    @PutMapping("/productos/{id}")
    public ResponseEntity<ProductoDTO> actualizarProducto(@PathVariable Long id, 
                                                         @Valid @RequestBody ProductoDTO productoDTO) {
        ProductoDTO productoActualizado = productoService.actualizarProducto(id, productoDTO);
        return ResponseEntity.ok(productoActualizado);
    }

    @DeleteMapping("/productos/{id}")
    public ResponseEntity<Void> eliminarProducto(@PathVariable Long id) {
        productoService.eliminarProducto(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/productos/{id}")
    public ResponseEntity<ProductoDTO> obtenerProductoPorId(@PathVariable Long id) {
        ProductoDTO producto = productoService.obtenerProductoPorId(id);
        return ResponseEntity.ok(producto);
    }

    @GetMapping("/productos")
    public ResponseEntity<List<ProductoDTO>> obtenerTodosLosProductos() {
        List<ProductoDTO> productos = productoService.obtenerTodosLosProductos();
        return ResponseEntity.ok(productos);
    }

    @GetMapping("/productos/categoria/{categoria}")
    public ResponseEntity<List<ProductoDTO>> obtenerProductosPorCategoria(@PathVariable Categoria categoria) {
        List<ProductoDTO> productos = productoService.obtenerProductosPorCategoria(categoria);
        return ResponseEntity.ok(productos);
    }

    @GetMapping("/productos/buscar")
    public ResponseEntity<List<ProductoDTO>> buscarProductosPorNombre(@RequestParam String nombre) {
        List<ProductoDTO> productos = productoService.buscarProductosPorNombre(nombre);
        return ResponseEntity.ok(productos);
    }

    @GetMapping("/productos/precio")
    public ResponseEntity<List<ProductoDTO>> obtenerProductosPorRangoDePrecio(
            @RequestParam BigDecimal precioMin, 
            @RequestParam BigDecimal precioMax) {
        List<ProductoDTO> productos = productoService.obtenerProductosPorRangoDePrecio(precioMin, precioMax);
        return ResponseEntity.ok(productos);
    }

    @GetMapping("/productos/stock")
    public ResponseEntity<List<ProductoDTO>> obtenerProductosConStock() {
        List<ProductoDTO> productos = productoService.obtenerProductosConStock();
        return ResponseEntity.ok(productos);
    }

    @PatchMapping("/productos/{id}/stock")
    public ResponseEntity<ProductoDTO> actualizarStock(@PathVariable Long id, 
                                                      @RequestParam Integer stock) {
        ProductoDTO productoActualizado = productoService.actualizarStock(id, stock);
        return ResponseEntity.ok(productoActualizado);
    }

    // ENDPOINTS DE CATEGORIAS
    
    @PostMapping("/categorias")
    public ResponseEntity<CategoriaDTO> crearCategoria(@Valid @RequestBody CategoriaDTO categoriaDTO) {
        CategoriaDTO categoriaCreada = categoriaService.crearCategoria(categoriaDTO);
        return ResponseEntity.ok(categoriaCreada);
    }

    @GetMapping("/categorias")
    public ResponseEntity<List<CategoriaDTO>> obtenerTodasLasCategorias() {
        List<CategoriaDTO> categorias = categoriaService.obtenerTodasLasCategorias();
        return ResponseEntity.ok(categorias);
    }

    @GetMapping("/categorias/{tipo}")
    public ResponseEntity<CategoriaDTO> obtenerCategoriaPorTipo(@PathVariable Categoria tipo) {
        CategoriaDTO categoria = categoriaService.obtenerCategoriaPorTipo(tipo);
        return ResponseEntity.ok(categoria);
    }

    @DeleteMapping("/categorias/{id}")
    public ResponseEntity<Void> eliminarCategoria(@PathVariable Long id) {
        categoriaService.eliminarCategoria(id);
        return ResponseEntity.noContent().build();
    }
}