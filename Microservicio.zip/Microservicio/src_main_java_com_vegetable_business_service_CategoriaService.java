package com.vegetable.business.service;

import com.vegetable.business.dto.CategoriaDTO;
import com.vegetable.business.model.Categoria;

import java.util.List;

public interface CategoriaService {
    
    CategoriaDTO crearCategoria(CategoriaDTO categoriaDTO);
    
    List<CategoriaDTO> obtenerTodasLasCategorias();
    
    CategoriaDTO obtenerCategoriaPorTipo(Categoria categoria);
    
    void eliminarCategoria(Long id);
}