```java
package com.vegetable.business.dto;

import com.vegetable.business.model.Categoria;
import jakarta.validation.constraints.NotNull;

public class CategoriaDTO {
    private Long id;

    @NotNull(message = "El tipo de categoría es obligatorio")
    private Categoria categoria;

    private String descripcion;
    
    public CategoriaDTO() {}
    
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public Categoria getCategoria() { return categoria; }
    public void setCategoria(Categoria categoria) { this.categoria = categoria; }
    
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
}
```