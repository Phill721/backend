```markdown
# Vegetable Business (Spring Boot)

Proyecto ejemplo con Spring Boot, JPA y H2 basado en el código proporcionado para gestión de productos y categorías.

Cómo ejecutar:
1. Tener Java 17 y Maven instalados.
2. En la carpeta del proyecto ejecutar:
   mvn spring-boot:run

Endpoints principales:
- /api/productos
- /api/categorias

La consola H2 está disponible en /h2-console (URL: jdbc:h2:mem:vegetabledb)

Notas:
- DTOs y validaciones incluidas.
- Los métodos "eliminar" realizan soft-delete (campo activo/activa).
```