package com.vegetable.business.mapper;

import com.vegetable.business.dto.ProductoDTO;
import com.vegetable.business.model.ProductoEntity;
import com.vegetable.business.model.CategoriaEntity;
import org.springframework.stereotype.Component;

@Component
public class ProductoMapper {

    public ProductoDTO toDTO(ProductoEntity entity) {
        if (entity == null) {
            return null;
        }
        
        ProductoDTO dto = new ProductoDTO();
        dto.setId(entity.getId());
        dto.setNombre(entity.getNombre());
        dto.setDescripcion(entity.getDescripcion());
        dto.setPrecio(entity.getPrecio());
        dto.setImagen(entity.getImagen());
        dto.setImagen2(entity.getImagen2());
        dto.setImagen3(entity.getImagen3());
        dto.setImagen4(entity.getImagen4());
        dto.setCategoria(entity.getCategoria().getCategoria());
        dto.setStock(entity.getStock());
        
        return dto;
    }

    public ProductoEntity toEntity(ProductoDTO dto, CategoriaEntity categoriaEntity) {
        if (dto == null) {
            return null;
        }
        
        ProductoEntity entity = new ProductoEntity();
        entity.setId(dto.getId());
        entity.setNombre(dto.getNombre());
        entity.setDescripcion(dto.getDescripcion());
        entity.setPrecio(dto.getPrecio());
        entity.setImagen(dto.getImagen());
        entity.setImagen2(dto.getImagen2());
        entity.setImagen3(dto.getImagen3());
        entity.setImagen4(dto.getImagen4());
        entity.setCategoria(categoriaEntity);
        entity.setStock(dto.getStock() != null ? dto.getStock() : 0);
        entity.setActivo(true);
        
        return entity;
    }
}