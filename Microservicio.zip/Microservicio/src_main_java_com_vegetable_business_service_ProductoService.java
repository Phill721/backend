package com.vegetable.business.service;

import com.vegetable.business.dto.ProductoDTO;
import com.vegetable.business.model.Categoria;

import java.math.BigDecimal;
import java.util.List;

public interface ProductoService {
    
    ProductoDTO crearProducto(ProductoDTO productoDTO);
    
    ProductoDTO actualizarProducto(Long id, ProductoDTO productoDTO);
    
    void eliminarProducto(Long id);
    
    ProductoDTO obtenerProductoPorId(Long id);
    
    List<ProductoDTO> obtenerTodosLosProductos();
    
    List<ProductoDTO> obtenerProductosPorCategoria(Categoria categoria);
    
    List<ProductoDTO> buscarProductosPorNombre(String nombre);
    
    List<ProductoDTO> obtenerProductosPorRangoDePrecio(BigDecimal precioMin, BigDecimal precioMax);
    
    List<ProductoDTO> obtenerProductosConStock();
    
    ProductoDTO actualizarStock(Long id, Integer nuevoStock);
}