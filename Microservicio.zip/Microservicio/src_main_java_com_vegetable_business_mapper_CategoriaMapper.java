package com.vegetable.business.mapper;

import com.vegetable.business.dto.CategoriaDTO;
import com.vegetable.business.model.CategoriaEntity;
import org.springframework.stereotype.Component;

@Component
public class CategoriaMapper {

    public CategoriaDTO toDTO(CategoriaEntity entity) {
        if (entity == null) {
            return null;
        }
        
        CategoriaDTO dto = new CategoriaDTO();
        dto.setId(entity.getId());
        dto.setCategoria(entity.getCategoria());
        dto.setDescripcion(entity.getDescripcion());
        
        return dto;
    }

    public CategoriaEntity toEntity(CategoriaDTO dto) {
        if (dto == null) {
            return null;
        }
        
        CategoriaEntity entity = new CategoriaEntity();
        entity.setId(dto.getId());
        entity.setCategoria(dto.getCategoria());
        entity.setDescripcion(dto.getDescripcion());
        entity.setActiva(true);
        
        return entity;
    }
}