package com.vegetable.business.service.impl;

import com.vegetable.business.dto.ProductoDTO;
import com.vegetable.business.mapper.ProductoMapper;
import com.vegetable.business.model.Categoria;
import com.vegetable.business.model.CategoriaEntity;
import com.vegetable.business.model.ProductoEntity;
import com.vegetable.business.repository.CategoriaRepository;
import com.vegetable.business.repository.ProductoRepository;
import com.vegetable.business.service.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class ProductoServiceImpl implements ProductoService {

    @Autowired
    private ProductoRepository productoRepository;
    
    @Autowired
    private CategoriaRepository categoriaRepository;
    
    @Autowired
    private ProductoMapper productoMapper;

    @Override
    public ProductoDTO crearProducto(ProductoDTO productoDTO) {
        CategoriaEntity categoriaEntity = categoriaRepository.findByCategoria(productoDTO.getCategoria())
                .orElseThrow(() -> new RuntimeException("Categoría no encontrada: " + productoDTO.getCategoria()));
        
        ProductoEntity productoEntity = productoMapper.toEntity(productoDTO, categoriaEntity);
        ProductoEntity productoGuardado = productoRepository.save(productoEntity);
        return productoMapper.toDTO(productoGuardado);
    }

    @Override
    public ProductoDTO actualizarProducto(Long id, ProductoDTO productoDTO) {
        ProductoEntity productoExistente = productoRepository.findByIdAndActivoTrue(id)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado con ID: " + id));
        
        if (productoDTO.getNombre() != null) productoExistente.setNombre(productoDTO.getNombre());
        if (productoDTO.getDescripcion() != null) productoExistente.setDescripcion(productoDTO.getDescripcion());
        if (productoDTO.getPrecio() != null) productoExistente.setPrecio(productoDTO.getPrecio());
        if (productoDTO.getImagen() != null) productoExistente.setImagen(productoDTO.getImagen());
        if (productoDTO.getImagen2() != null) productoExistente.setImagen2(productoDTO.getImagen2());
        if (productoDTO.getImagen3() != null) productoExistente.setImagen3(productoDTO.getImagen3());
        if (productoDTO.getImagen4() != null) productoExistente.setImagen4(productoDTO.getImagen4());
        if (productoDTO.getStock() != null) productoExistente.setStock(productoDTO.getStock());
        
        if (productoDTO.getCategoria() != null && 
            !productoExistente.getCategoria().getCategoria().equals(productoDTO.getCategoria())) {
            CategoriaEntity nuevaCategoria = categoriaRepository.findByCategoria(productoDTO.getCategoria())
                    .orElseThrow(() -> new RuntimeException("Categoría no encontrada: " + productoDTO.getCategoria()));
            productoExistente.setCategoria(nuevaCategoria);
        }
        
        ProductoEntity productoActualizado = productoRepository.save(productoExistente);
        return productoMapper.toDTO(productoActualizado);
    }

    @Override
    public void eliminarProducto(Long id) {
        ProductoEntity producto = productoRepository.findByIdAndActivoTrue(id)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado con ID: " + id));
        producto.setActivo(false);
        productoRepository.save(producto);
    }

    @Override
    @Transactional(readOnly = true)
    public ProductoDTO obtenerProductoPorId(Long id) {
        ProductoEntity producto = productoRepository.findByIdAndActivoTrue(id)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado con ID: " + id));
        return productoMapper.toDTO(producto);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProductoDTO> obtenerTodosLosProductos() {
        return productoRepository.findByActivoTrue()
                .stream()
                .map(productoMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProductoDTO> obtenerProductosPorCategoria(Categoria categoria) {
        return productoRepository.findByCategoriaCategoriaAndActivoTrue(categoria)
                .stream()
                .map(productoMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProductoDTO> buscarProductosPorNombre(String nombre) {
        return productoRepository.findByNombreContainingIgnoreCaseAndActivoTrue(nombre)
                .stream()
                .map(productoMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProductoDTO> obtenerProductosPorRangoDePrecio(BigDecimal precioMin, BigDecimal precioMax) {
        return productoRepository.findByPrecioBetween(precioMin, precioMax)
                .stream()
                .map(productoMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProductoDTO> obtenerProductosConStock() {
        return productoRepository.findByStockGreaterThanAndActivoTrue(0)
                .stream()
                .map(productoMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public ProductoDTO actualizarStock(Long id, Integer nuevoStock) {
        ProductoEntity producto = productoRepository.findByIdAndActivoTrue(id)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado con ID: " + id));
        producto.setStock(nuevoStock);
        ProductoEntity productoActualizado = productoRepository.save(producto);
        return productoMapper.toDTO(productoActualizado);
    }
}